//  Programming Project 1
//
//  NetID: jchoi215
//  Name: Jae Rim Choi
//  Enviroment: windows 10,  text editior: Atom   compiler: gcc compiler
//
//  Summmery: program that takes in values from user, duplicates it, sorts it,
//             and finds it (binear vs linear). Displaying index and comparisons.
//
//  NOTE: To see ORIGNAL & DUPLICATE values  PLEASE uncomment showArray @ bottom
//
//

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

void showArray (int originalArray[], int duplicateArray[], int finalIndex){

      // displays original array
      int i = 0;
      printf("\n\n   ** DISPLAY ORIGNAL ARRAY ** \n");
      for(i = 0; i < finalIndex; ++i)
      {
          if(i%10 == 0) printf("\n");
          printf("%d ", originalArray[i]);
          // allowed proper spacing for neater display
          if(originalArray[i] < 10) printf("   ");
          else if(originalArray[i] >= 10 && originalArray[i] < 100) printf("  ");
          else if(originalArray[i] >= 100 && originalArray[i] < 1000) printf(" ");
      }

      // displays copied array, sorted
      printf("\n\n   ** DISPLAY COPIED & SORTED ARRAY ** \n");
      for(i = 0; i < finalIndex; ++i)
      {
          if(i%10 == 0) printf("\n");
          printf("%d ", duplicateArray[i]);
          // allowed proper spacing for neater display
          if(duplicateArray[i] < 10) printf("   ");
          else if(duplicateArray[i] >= 10 && duplicateArray[i] < 100) printf("  ");
          else if(duplicateArray[i] >= 100 && duplicateArray[i] < 1000) printf(" ");
      }

}

void displayScreen(int index, int numComparison, int find){
      // for checking purposes -- show if found/not found -- index & # of comparison
      if(index == -1)
      {
          printf("     Search Value: %d\n     *NOT found in the array*\n", find);
          printf("     # of comparison: %d\n\n",numComparison );
      }
      else
      {
          printf("     Search Value: %d\n     Index of position: %d\n", find, index);
          printf("     # of comparison: %d\n\n",numComparison );
      }
}

void binearySearch(int Array[], int find, int limit, int *index, int *numComparison){
     int low = 0;
     int mid = 0;
     int high = limit;

     // split the array into two parts, check uppper & lower -- find which region
     while(high >= low)
     {
           mid = (high + low) /2;

           //  ---  search value is in UPPER region
           if(Array[mid] < find) low = mid+1;
           //  --- search valu is in LOWER region
           else if(Array[mid] > find) high = mid-1;
           //  --- search value is found & index is returned
           else if(Array[mid] == find)
           {
              *index = mid;
              break;
           }
           ++*numComparison;
     }
}

void linearSearch(int Array[], int find, int limit, int *index, int *numComparison){
     int i = 0;
     // find the search value using linear search, return index & # of searches
     for(i = 0 ; i < limit; ++i)
     {
           ++*numComparison;
           if(Array[i] == find)
           {
                 *index = i;
                 break;
           }
     }
}

int getInput(){
      int input = 0;
      char returnChar;
      // ask user for  -- search value
      printf("  >> Please input value to search: ");
      scanf("%d%c", &input, &returnChar);
      printf("\n  ... DONE \n");
      return input;
}

int partition(int incomingArray[], int start, int end){

      int left = start;
      int right = end;
      int temp;
      bool finished = false;

      int mid = start + (end - start) / 2;
      int pivot = incomingArray[mid];

      while(!finished)
      {
          // move index to place where condition fails
          while( incomingArray[left]  < pivot ) ++left;
          while( incomingArray[right] > pivot) --right;

          // this while loop is complete when this is true
          if(left >= right) finished = true;
          else
          {
              // swap the values where the condition failed
              temp = incomingArray[left];
              incomingArray[left] = incomingArray[right];
              incomingArray[right]= temp;

              //now the value have been swaped, keep going
              ++left;
              --right;
          }
      }
      return right;
}

void quickSort(int incomingArray[], int start, int finalIndex){
      // split the array in to 2 parts, sort 1st & 2nd half
      if(start>= finalIndex) return;
      int mid = partition(incomingArray,start, finalIndex);
      quickSort(incomingArray, start, mid);
      quickSort(incomingArray, mid+1, finalIndex);

}

int* transferData(int *incoming, int limit, int newSize){
      int i = 0;
      // re-allocating array with new size & copy
      int * newArray =  (int *) malloc (newSize * sizeof(int));
      for(i = 0; i < limit; ++i){
          newArray[i] = incoming[i];
      }
      // transfer to new array, delete old incoming array
      free( incoming );
      return newArray;
}

int * copyArray(int oldArray[], int size, int limit){

  // allocate space for duplication of array
  printf("  >> creating copy of original array");
  int * duplicateArray =  (int *) malloc (size * sizeof(int));

  // copy from one array to the next
  int i = 0;
  for(i = 0; i < limit; ++i){
    duplicateArray[i] = oldArray[i];
  }

  printf("\n  ... DONE \n");
  return duplicateArray;
}

int* insertValue(int* size, int* finalIndex){

  printf("\n\n        ** INPUT SYSTEM **       \n\n ");
  printf(" >> Input value into the system (-999 to end input): ");

   int * tempArray =  (int *) malloc (*size * sizeof(int));

   int index = 0;
   bool finished = false;

   while(!finished)
   {
          int input = 0;
          int rKey = 0;
          // get number input from the user, stop taking input when -999
          scanf("%d%c",&input,&rKey);
          if(input == -999 || rKey == -999) finished = true;
          else if(index >= *size){

              int prevSize = *size;
              *size = *size * 2;
              // if element > size -- re-Allocate and transfer datas
              tempArray = transferData(tempArray, prevSize, *size);
              tempArray[index] = input;
              ++index;

          }
          else
          {
            // if element < size just input value into proper index
            tempArray[index] = input;
            ++index;
          }
   }
  // return final index which needed for index limit
  * finalIndex = index;

  printf("\n  ... DONE \n");
  return tempArray;
}

int main(){

      int limit = 2;
      int finalIndex = 2;
      int* originalArray;

      // store incoming value into array, allocate more space if needed
      originalArray = insertValue(&limit, &finalIndex);

      // generate same amount of space for duplicate array
      int * duplicateArray = copyArray(originalArray,limit, finalIndex);
      printf("  >> Quick sorting array");

      // quick sort the duplicate arry
      quickSort(duplicateArray, 0, finalIndex-1);
      printf("\n  ... DONE \n");

      // ask user for value to search for in the system
      int userInput = getInput();


      printf("\n\n ==============[ RESULTS OF SEARCH ] =============\n\n\n");
      int index = -1;
      int numComparison = 0;
      printf("   ** USING LINEAR SEARCH **\n\n");
      // use linear search for find index & number of comparisons
      linearSearch(originalArray, userInput, finalIndex, &index, &numComparison);
      // display the linear search results to the screen
      displayScreen( index,  numComparison,  userInput);

      index = -1;
      numComparison = 1;
      printf("   ** USING BINEARY SEARCH **\n\n");

      // use bineary search for find index & number of comparisons
      binearySearch(duplicateArray,userInput, finalIndex-1,  &index, &numComparison);
      // display the bineary search result to screen
      displayScreen( index,  numComparison,  userInput);

      // NOTE: showArray displays all values inputed into the system
      // NOTE: uncomment the function if this part is necesary for grading
      //showArray(originalArray, duplicateArray, finalIndex);

      return 0;
}
