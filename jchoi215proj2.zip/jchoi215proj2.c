//  Programming Project 2
//
//  NetID: jchoi215
//  Name: Jae Rim Choi
//  Enviroment: windows 10,  text editior: Atom   compiler: gcc compiler
//
//  Summmery: program that takes in string from user, checks if brackets are balanced.
//            if not balanced * prompt user missing or expecting bracket in their
//            proper posiiton. Just Q to exit program
//
//            ANOTHER feature: -d debug mode
//            Display when characters are being pushed or popped from the stack
//            in case increasing the array size is necessay show:
//            old array size, characters on stack, what is being copied to new
//            array and new array with new pushed character along with size.
//
//            Thank you and have an GREAT DAY!

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct stack{

  char * arr;
  int  top;
  int  size;

}stack;


bool  fail_case( int failType, int num_space, char failChar, char oriString[], bool debug){

    // fix display for readability
    if(debug) printf("\n\n");

    // depending on if "Missing" or  "Expecting" print proper to screen
    int i;
    if(failType == 1)
    {
        printf("%s\n",oriString);
        for(i = 0; i < num_space; ++i) printf(" ");;
        printf("^ missing %c \n\n", failChar);
    }
    else
    {
        printf("%s\n",oriString);
        for(i = 0; i < num_space; ++i) printf(" ");
        printf("^ expecting %c \n\n", failChar);
    }
    return true;
}


void  stack_init(stack * pile){
    // initinalzie the stack, orignal size 2 & allocate space, empty stack -1
    pile->size =  2;
    pile->top  = -1;
    pile->arr = (char *) malloc ( (pile->size) * sizeof(char));
}


int   stack_empty(stack * pile){
    // check if top is empty & return true if so
    if(pile->top == -1) return 1;
    else                return 0;
}


void  stack_push(stack * pile, char c, bool debug){
    // ** if size is too small to contain all value -> grow size of array **
    if(pile->top >= pile->size-1)
    {
        int i;

        // if debug mode is on - show old & new array & what is being copied
        if(debug)
        {
          printf("\n  Old size: %d  Contains: %s \n", pile->size, pile->arr);
          printf("  create new allocated space: %d\n",pile->size +2);
          printf("  characters being copied over to new: %d \n\n", pile->top+1);
        }

        // allocate new space with old size + 2 for new array
        char * newArray = (char *) malloc ((pile->size + 2) * sizeof(char));

        // copy old array value to the new array
        for(i = 0; i <= pile->top; ++i)  newArray[i] = pile->arr[i];

        // push character onto stack
        newArray[pile->top+1] = c;
        // place null character at end for display fix
        newArray[pile->top+2] = '\0';
        // place old array pointer to value;
        char * old = pile->arr;
        // connect new array with stored values to stack
        pile->arr = newArray;
        // increase size + 2 && added character to stack +1;
        pile->size += 2;
        pile->top  += 1;

        // when in debug mode - display pushed char & new array with char
        if(debug)
        {
            printf(" PUSH: %c\n", c);
            printf("\n   New size: %d  Contains: %s \n\n", pile->size, pile->arr);
        }

        // delete the old memory
        free(old);
    }
    else
    {
        // ** when size is big enough just place in value **
        // since char is being pushed; stack +1;
        pile->top+= 1;
        // debug mode display char that is pushed to stack
        if(debug) printf(" PUSH: %c\n", c);
        pile->arr[pile->top] = c;
        // place null key
        pile->arr[pile->top+1] = '\0';
    }
}


char  stack_pop(stack * pile){
    // store what was at top of the stack
    char pLetter = pile->arr[pile->top];
    // override && delete value at top
    pile->arr[pile->top] = '\0';
    // decrease stack by -1
    pile->top  -=1;
    // return the value that was on top of the stack used for debugging
    return pLetter;
}


char  stack_access(stack * pile){
    // return what is sitting at top of stack
    return (pile->arr[pile->top]);
}


void  stack_reset(stack * pile){
    // free char memory & stack memory
    free(pile->arr);
    free(pile);
}


char  yinYang(char c){
    // bracket comes in - return the opposite
         if(c == '}') return '{';
    else if(c == ']') return '[';
    else if(c == ')') return '(';
    else if(c == '>') return '<';

    else if(c == '{') return '}';
    else if(c == '[') return ']';
    else if(c == '(') return ')';
    else if(c == '<') return '>';
}


bool   isOpening(char c){
    // check if openning bracket & return true if it is.
    if(  c == '{' || c == '[' || c == '(' || c == '<') return true;
    else return false;
}


bool   isClosing(char c){
    // check if closing  bracket & return true if it is.
    if( c == '}' || c == ']' || c == ')' || c == '>') return true;
    else return false;
}


void symbol_check(bool debug){

   // create space to hold incoming string
   char line[300];

   // prompt user information how to go about the system
   printf("Input line of text ( Q to quit )       \n\n");
   // keep running till end of file or "other trigger"
   while(fgets(line, 300, stdin) != NULL)
   {
         // get rid of return or new line character at end of string
         line[strcspn(line,"\n\r")] = '\0';
         // get the length of the string
         int stringLength = strlen(line);

         //  **  JUST q or Q ** close the break the loop ending program
        if( strcspn(line, "qQ") == 0 &&  stringLength == 1)
        {
            printf("\n [  %s was accepted ]\n\n\n >> system closing <<\n\n", line);
            break;
        }

        int i;
        bool fail_flag = false;
        // create the stack
        stack * pile = (stack *) malloc (sizeof(stack));
        // initinalize the stack
        stack_init(pile);

        // check every character in string till end
        for(i = 0; i < stringLength; ++i)
        {
            // if character is openning bracket -> push to stack
            if( isOpening(line[i]) ) stack_push(pile, line[i], debug);

            // if character is closing bracket
            else if( isClosing(line[i]) )
            {
                // stack is empty -> display missing **
                if( stack_empty(pile) )
                    fail_flag = fail_case(1, i, yinYang(line[i]), line, debug);
                // if opposite bracket is on top of stack POP the character
                else if( stack_access(pile) == yinYang(line[i]))
                {
                    char popped = stack_pop(pile);
                    // if in debug mode show what is being popped from stack
                    if(debug) printf(" POP:  %c\n", popped);
                }

                // if something is on stack but NOT opposite bracket
                else if( stack_access(pile) != yinYang(line[i]))
                    // display EXPECTED ** character
                    fail_flag = fail_case(2,i, yinYang( stack_access(pile) ), line, debug);

            }
            if(fail_flag) break;  // if any fail_flag is on - stop checking
        }

        // case 1: nothing on stack && no fail flags
        if( stack_empty(pile) && !fail_flag )
        {
          if(debug) printf("\n\n");
          printf("%s\n\n ** Expression is balanced **\n\n",line);
        }

        // case 2: something is on stack && no fail flags
        else if( !stack_empty(pile) && !fail_flag )
          // special case --display missing
          fail_case(1, stringLength+4, yinYang( stack_access(pile) ), line, debug);

          // reprompt user instruction
        printf("=================================================\n\n");
        printf("Input line of text ( Q to quit )                 \n\n");
        stack_reset(pile);  // delete old stack
    }
}


bool isDebug(int argc, char** argv){
    int i;
    // check if any arguments are "-d" with exact length return true if so.
    for (i = 0; i < argc; i++)
    if ( argv[i][0] == '-' && argv[i][1] == 'd' && strlen(argv[i]) == 2) return true;
    return false;
}


void display_title (bool debug){
    // display current status & what kind of program it is
    printf("\n\n");
    if(debug) printf("       < DEBUG MODE >       \n\n");
    printf("   SYMBOL BALANCE CHECKER             \n\n");
}


int main(int argc, char** argv){
    // check if debug mode is on
    bool status = isDebug(argc, argv);
    // depending on status show that its in debug mode & title
    display_title( status );
    // check strings if brackets are balanced in the program
    symbol_check( status );
    return 0;
}
