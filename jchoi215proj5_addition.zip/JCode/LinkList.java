

// public class LinkList
// {
//   public static void main (String[] args)
//   {


//     List vList = new List();
//     // List  oList = new List();
    
//     vList.push (5);
//     vList.push (18);
//     vList.push (10);
//     vList.push (3);
//     vList.show();
    
//     System.out.println("   REMOVE TESTING   \n"); 
  

//   //   oList.push('+');
//   //   oList.push('-');
//   //   oList.push('/');
//   //   oList.push('*');
//   //   oList.show();
    
//   //   System.out.println("   REMOVE TESTING   \n"); 
    
//     vList.pop ();
//     vList.show();
//   //   oList.pop ('/');
//   //   oList.show();
//   }
// }



// ==================================================================================
//
//                             INT LINK LIST & NODES 
//
// ==================================================================================
 
class node
{
    private int val;
    private node next;
    
    int getVal () {return val; } 
    void setNext (node n) {next = n; } 
    node getNext() {return next; } 

    public node (int v1)
    {
      val = v1;
      next = null;
    }
}
 

class List
{

  private node head;
  public List(){ head  = null; }


  public void show(){
      node temp = head;
      while(temp != null)
      {
         System.out.print ("\n" + temp.getVal());
         temp = temp.getNext();
      }
  }
  

  public void push (int v1){
    node temp = new node (v1);
    temp.setNext(head);
    head = temp;
  }


  public void pop(){
     if(head == null) return;
     head = head.getNext();
     return;
  }


  public int isEmpty(){
    if(head != null) return 1;
    else return 0;
  }


  public int top(){
    if(head == null) System.out.println("List is empty\n");
    return head.getVal();
  } 
}




  // public void pop (int i){
  //     node cur = head;
  //     node prev = null; 

  //     if (cur.getVal() == i)
  //     {
  //        if(cur.getNext() == null) head = null;
  //        else head = head.getNext();
  //     }

  //     else
  //     {
  //       while(cur != null)
  //       {
  //         if(cur.getVal() == i) prev.setNext(cur.getNext());

  //         prev = cur;
  //         cur = cur.getNext();
  //       }
  //     }
  //    return;
  // }



