// Name: Jae Rim Choi
// NetID: jchoi215
// Exam 2

import java.io.*;
import java.util.*;

	public class jchoi215Exam2
	{
		public static void main( String args[] )
		{
			System.out.println("\n =================================== "  );
			System.out.println  (" |        EXAM 2: JAVA QUEUE       | ");
			System.out.println  (" =================================== \n");

			List pos_list = new List();
			List neg_list = new List();
			List mult_four_list  = new List();


			int num =  getInt(" Please input a number: ");

			while(num != 0)
			{
				if((num % 4) == 0)
				{
					mult_four_list.enqueue (num);
				}

				if(num > 0)
				{
					pos_list.enqueue (num);
				} 

				if(num < 0)
				{
					neg_list.enqueue (num);
				}

				num =  getInt(" Please input a number: ");
			}


			System.out.print("\n\nPositive values: \n");
			Print(pos_list);

			System.out.print("\n\nNegitive values: \n");
			Print(neg_list);

			System.out.print("\n\nThe Multiples of 4: \n");
			Print(mult_four_list);
		}



	public static void Print(List thisLink)
	{
		int skip = 1;
		if(thisLink.isEmpty())
		{
			System.out.println(" <empty list> ");
		}
		else
		{
			while(thisLink.isEmpty() == false)
			{
				int val = thisLink.front();
				
				System.out.print(val + "   ");
				if((skip %8) == 0) System.out.println();
				
				thisLink.dequeue();
				skip++;
			}			
		}

	}


	public static void display(String text)
	{
		System.out.println("\n =================================== "  );
		System.out.println  (text);
		System.out.println  (" =================================== \n");
	}



	public static int getInt(String outputText)
	{
		int val = -999; 
		Scanner reader = new Scanner (System.in);
		System.out.print(outputText);

		try     
		{
			return reader.nextInt();
		}
		catch( InputMismatchException nfe)   // in case when 2nd argument is INVALID
		{
			System.out.println("Invalid input, please try again");
			val = getInt(outputText);
		}
		
		return val;
	}

}