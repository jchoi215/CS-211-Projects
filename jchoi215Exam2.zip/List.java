

class List
{
	private Node head;


	// constructor head == null
	public void List()
	{
		head = null;
	}


	// this is removed from the END of the line
	public void enqueue (int a)
	{
		Node temp = new Node(a);

		if(head == null)
		{
			head = temp;			
		}
		else
		{
			Node front = head;
			Node back  = null;

			while(front != null)
			{
				back = front;
				front = front.getNext();
			}

			back.setNext( temp );
		}
	}



	// this removes form the top of the stack
	public void dequeue()
	{   
		if(head == null) return;
		else head = head.getNext();
	}


	// it attempt to return --> value
	// else it will return  --> -999
	public int front()
	{
		if(head != null) return head.getVals();
		else return -999;
	}


	public boolean isEmpty()
	{
		if(this.head == null) return true;
		else return false;
	}



}






class Node
{
	private int val;
	private Node next;

	Node(int a)
	{
		val  = a;
		next = null;
	}

	public void setNode(Node a) {next = a; }
	public void setNext(Node a) {next = a; }
	public Node getNext() {return next; }
	public int  getVals() {return val;  }
}