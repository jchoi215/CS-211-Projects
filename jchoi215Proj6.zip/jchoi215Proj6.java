// 
//  Name:  Jae Rim Choi
//  NetID: jchoi215
//  Project: 6
//  connected to .java
//



import java.io.*;
import java.util.*;

public class jchoi215Proj6
{
	private Airport[] airPort;


	public void jchoi215Proj6()             
	{                                    // allocate and set airPort
		airPort = new Airport[10];          // default size 10
		for(int i = 0; i < 10; i++)
		airPort[i] = new Airport(); 
	}	

 
	public void doResize(Scanner sc)
	{
		int val1 = 0;
		if ( sc.hasNextInt() == true ) val1 = sc.nextInt(); 
		else {System.out.println (" Integer value expected"); return; }
		System.out.println (" ** Performing the Resize Command with " + val1 + " **");


		airPort = new Airport[val1];         // reallocate new size
		for(int i = 0; i < val1; i++) airPort[i] = new Airport();  
	}




	public static void main (String[] args)
	{
		System.out.print("Please input command: ");
		
		// set up the data needed for the airport adjcency list
		jchoi215Proj6 airportData = new jchoi215Proj6();

		// set up an instance of the BufferedReader class to read from standard input
		BufferedReader br = new BufferedReader (new InputStreamReader (System.in));

		// stack used to prevent infinite loop keeping track of name of files
		Record recordedFile = new Record(); 

		// call the method that reads and parses the input
		airportData.processCommandLoop (br, recordedFile);

		System.out.println ("                ~ Goodbye ~");
	}
   



   
  public void processCommandLoop (BufferedReader br, Record recordedFile)
  {
    try 
    {   
		String inline = br.readLine();    // take in string from buffer  
		Scanner sc;


		while (inline != null)
		{   // if there happens to have ENTER get rid of it and continue
			while(inline.equals("")){ inline = br.readLine(); }
			

			sc = new Scanner (inline);
			if (inline == null) System.exit(1);   
			String command = sc.next();

			// take in user command, and continue processing
			if      (command.equals("q") == true) return;
			else if (command.equals("?") == true) showCommands();
			else if (command.equals("t") == true) doTravel(sc);
			else if (command.equals("r") == true) doResize(sc);
			else if (command.equals("i") == true) doInsert(sc);
			else if (command.equals("d") == true) doDelete(sc);
			else if (command.equals("l") == true) doList(sc);
			else if (command.equals("f") == true) doFile(sc, recordedFile);
			else if (command.equals("#") == true) ;
			else    System.out.println (" Command is not known: " + command);
			
			inline = br.readLine();   // get next line
		}

    }
    catch (IOException ioe) { System.out.println (" Error in Reading - Assuming End of File"); }
 }
 




 public void showCommands()
 { // user input ? display
   System.out.println ("The commands for this project are:");
   System.out.println ("  q ");
   System.out.println ("  ? ");
   System.out.println ("  # ");
   System.out.println ("  t <int1> <int2> ");
   System.out.println ("  r <int> ");
   System.out.println ("  i <int1> <int2> ");
   System.out.println ("  d <int1> <int2> ");
   System.out.println ("  l ");
   System.out.println ("  f <filename> ");
 }
 



 public void doTravel(Scanner sc)
 {

	int val1 = 0, val2 = 0;   
	if ( sc.hasNextInt() == true ) val1 = sc.nextInt(); else {System.out.println (" >> Integer value expected"); return; } 
	if ( sc.hasNextInt() == true ) val2 = sc.nextInt(); else {System.out.println (" >> Integer value expected"); return; }   

	val1 -=1; val2 -=1;              // change value to index
	int limit = airPort.length;      // get max length


	if ( !( -1 < val1 && val1 < limit  ) || !(-1 < val2 && val2 < limit ) )  // check if user input is in range
	{
		System.out.println(" Checking fight path:   " + (val1+1) + " => " + (val2+1) + "  [ INVALID ]");
		return; 
	} 
	if ( airPort[val1] == null || airPort[val2] == null)                      // if its null, prompt & return
	{
		System.out.println(" Checking fight path:   " + (val1+1) + " => " + (val2+1) + "  [ INVALID ]");
		return; 
	}

	// create array with max size + 2,  0th position is INDEX, 
	int[] dfsList = new int[ limit + 2];
	for(int i = 0; i < dfsList.length; i++) dfsList[i] = -7; // negitive value default


	dfsList[0] = 2;     // set next index
	dfsList[1] = val1;  // push src value


	DFS(val1, dfsList); // do dfs search
	dfsList[ dfsList[0] ] = -1; // -1 marks the end of the array

	for(int i = 0; i < limit; i++) airPort[i].visitReset();  // reset positions visited for next traveral

	if( isReachable(dfsList, val2) )                         // isReachable checks if its reachable
		System.out.println(" Checking fight path:   " + (val1+1) + " => " + (val2+1) + "  [  VALID  ]");
	else 
		System.out.println(" Checking fight path:   " + (val1+1) + " => " + (val2+1) + "  [ INVALID ]");
 }
 



public boolean isReachable (int dfsList[], int dest)
{   // checks the array to see if the value was reached
	for(int i = 1; dfsList[i] != -1; i++) if( dfsList[i] == dest) return true;
	return false;   // if not, return false 
}



 
 public void DFS(int src, int dfsList[])
 {
	airPort[src].markVisited();           // mark the visited
	node read = airPort[src].getNode();   // get connected node

	while(read != null)                   // port has not been visited
	{
		if( !airPort[read.getPort()].visitStatus() )
		{ 
			int i      = dfsList[0];      // get index
			int port   = read.getPort();  // get dest value
			dfsList[i] = port;            // set it into visited array
			dfsList[0] +=1;               // update index
			
			DFS(port, dfsList);           // recursive dfs
		}
		read = read.getNext();            // keep going till null
	}
 }



 public void doInsert(Scanner sc)
 {
      int i, val1= 0, val2 = 0, length = airPort.length;  

      if ( sc.hasNextInt() == true ) val1 = sc.nextInt(); else {System.out.println (" >> Integer value expected"); return; }
      if ( sc.hasNextInt() == true ) val2 = sc.nextInt(); else {System.out.println (" >> Integer value expected"); return; }

      val1 -=1; val2 -=1;                   // convert to index
                                            // check if its in range
      if ( !( -1 < val1 && val1 < length  ) || !(-1 < val2 && val2 < length ) )
      {                                     // IF OUT OF RANGE - prompt to screen & return
        System.out.println(" ** Invalid Airport found, line was ignored **"); return;
      }
      else if(val1 != val2) airPort[val1].push(val2); // add edge from source to destination
 }
 




 public void doDelete(Scanner sc)
 {
    int val1 = 0, val2 = 0;   

    if ( sc.hasNextInt() == true ) val1 = sc.nextInt(); else {System.out.println (" >> Integer value expected"); return; } 
    if ( sc.hasNextInt() == true ) val2 = sc.nextInt(); else {System.out.println (" >> Integer value expected"); return; }  

	System.out.print(" Delete flight request: " + val1 + " => " + val2);   // output to screen which vertex to delete

    val1 -= 1; val2 -= 1;                      // convert value to index
	airPort[val1].pop(val2);                   // remove the edge connecting them
 }




 public void doList(Scanner sc)
 {
	System.out.println("\n +========================================= ");  // display Airport connections
	System.out.println(  " *        DISPLAYING FLIGHT ROUTES        * "); 
	System.out.println(  " +========================================= ");
	
	int limit; 
	int length = airPort.length;


	for(int i =0; i < length; i++)              // loop through and print to screen vertex
	{
		System.out.print(" [" + (i+1) + "]  "); // if it happens to be empty, display to screen

		if(airPort[i].getNode() == null) System.out.print("         -- empty --");
		else
		{
			node read = airPort[i].getNode();
			if(read != null)
			{
				while( read != null )
				{
					int connectedPort = read.getPort() +1;
					System.out.print(connectedPort + " ");
					read = read.getNext();
				}
			}
		}
		System.out.print("\n");
	}
	System.out.println(  " ========================================== \n");
 }



 
	public void doFile(Scanner sc, Record recordedFile)
	{
		String fname = null;

		if ( sc.hasNext() == true )  fname = sc.next();
		else{ System.out.println ("Filename expected");   return;}

		if( !recordedFile.FileExist(fname) )              // if file does not exist in the stack
		{                                                 // add it to the stack
			recordedFile.InsertFile(fname);               // print to screen which file is being read
			System.out.println("\n +========================================= "); 
			System.out.println(  " *  READING:     "+fname+"           * "     ); 
			System.out.println(  " +========================================= ");

			try(BufferedReader br = new BufferedReader(new FileReader(fname))) // new buffer / read
			{
				this.processCommandLoop (br, recordedFile);                    // process command * close file
				System.out.println("\n +========================================= "            );
				System.out.println(  " *  CLOSING:     "+recordedFile.topFile()+"           * "); 
				System.out.println(  " +========================================= \n "            );
				
				recordedFile.closeFile();                  // remove finished file
			}
			catch (IOException ioe) { System.out.println (" Error in Reading - Assuming End of File"); }
		}
	}
}