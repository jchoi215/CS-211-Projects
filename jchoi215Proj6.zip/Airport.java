// 
//  Name:  Jae Rim Choi
//  NetID: jchoi215
//  Project: 6
//  connected to jchoi215Proj6.java
//




class Airport
{
  private node head;  
  private boolean visited;
  private int length;


  public void Airport()                             
  { 
   head    = null;                       //  default setting 
   visited = false;                      
   length  = 0;
  }

  public int      getLength(){ return length; }    // returns length of linked list
  public boolean  visitStatus() {return visited; } // return visited status
  public void     markVisited() {visited = true; } // marks position as visited
  public void     visitReset() {visited = false; } // reset to false for visited
  public node     getNode() {return head; }        // returns head


  public void push (int v1)
  {
    node temp = new node (v1);            // push value to the stack
    length += 1;                          // grow the length
 

    if(head == null)                      // this takes care of empty case
    {                                     // set temp as head
       head = temp;
       return;
    }
    else if(temp.getPort() < head.getPort())
    {
      temp.setConnectTo(head);            // connect nodes based on condition
      head = temp;
      return;
    }

    node cur = head;                      
    while(cur != null)                    // cur will continue to move down
    {                                     // inserts it as sorted linked list
      if(cur.getPort() < temp.getPort())
      {
        if(cur.getNext() == null) cur.setConnectTo(temp);
        
        else if(temp.getPort() < cur.getNext().getPort())
        {
          temp.setConnectTo(cur.getNext());
          cur.setConnectTo(temp);
        }
      }
      cur = cur.getNext();      
    }
  }



  public void pop (int r)
  {
    if(head != null)                       // if head is NOT null
    {
      boolean found = false;               
      node pre = null;
      node cur = head;
      
      while(cur != null)                   // keep reading till everything is read
      {
        if(cur.getPort() == r)             // found the value - remove
        {
          if(pre == null)
          {
           if(head.getNext() == null) head = null;
           else head = head.getNext();
          }
          else
          {
           pre.setConnectTo(cur.getNext()); 
          }
          found = true;                     // mark as match has been found
          break;
        } 
        pre = cur;
        cur = cur.getNext();
      }

      if(found)                              // if match has been found: display to screen status
      {
        length -= 1;
        System.out.println("  [ACCEPTED] ");
      } 
      else                                   // other wise -display to screen status & reason
        System.out.println("  [ DENIED ] \n ** REASON: " + (r+1) + " is a invalid flight path **");
    }
    else
    {
        System.out.println("  [ DENIED ] \n ** REASON: Flight path list is empty  **\n");
      return;          
    }
  }



  public int isEmpty(){
    if(head != null) return 1;                // check of stack is empty
    else return 0;
  }



  public int top(){                           // get value on top of stack
    if(head == null) return -999;       
    return head.getPort();
  } 
}





class Record                                  // class that teals with files
{
  private fileNode head;                      // linked list head

  public void Record(){ head = null; }
  
  public void InsertFile(String s)            
  {
    fileNode temp = new fileNode(s);          // set temp as the new head
    if(head == null){ head = temp;}
    else
    {
      temp.setNextFile(head);
      head = temp;
    }
  }

  public boolean FileExist (String s)          
  {
    fileNode read = head;  
    while(read != null)                      // read till file has been found
    {                                        // if found return true
      if( read.getFile().equals(s) ) 
      {
        return true;
      }
      read = read.getNextFile();
    }
    return false;                            // else return false 
  }

  public void PrintFile ()                   
  {                                          // prints out all the files in stack
    fileNode read = head;  
    while(read != null)
    {
      System.out.println(read.getFile());
      read = read.getNextFile();
    }
  }

  public String topFile()                
  {
    return head.getFile();                   // returns file that is in head
  }

  public void closeFile ()
  {
    head = head.getNextFile();               // removes the file (pop)
  }
}




class fileNode
{
  private String name;
  private fileNode next;

  String   getFile(){ return name; }        // return name of file
  fileNode getNextFile(){ return next; }    // return next node
  void     setNextFile(fileNode node){ next = node; } // set connected node

  fileNode(String s)
  {                                         // set string as name of file in the node
    name = s;
    next = null;
  }
}


class node
{
    private int portNum;
    private node connectTo;                  

    void  setConnectTo(node n) {connectTo = n; } 
    int   getPort() {return portNum; } 
    node  getNext() {return connectTo; }

    node(int num)
    {
      portNum = num;
      connectTo = null;
    }

}

