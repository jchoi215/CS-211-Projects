
//
//
//   ** credits to Professor Troy for providing us with general print statements  **
//
//   Programming Project 4
//
//   Name:  Jae Rim Choi
//   NetID: jchoi215
//   Enviroment: windows 10,  text editior: Atom   compiler: gcc compiler
//
//  Summmery: Goal was a create a data structure that implements a
//            customer waiting list that might be used in a restaurant.
//            Program features includes:
//            * Adding clients to the waiting list
//            * Making reservations
//            * Verification of reservations (updating their status)
//            * Removing the clients from waiting list
//                    when seats of proper size is available
//            * Displaying all information regarding groups that are in line
//                     name, size and status
//            * Checking to see how many groups are in front of a specific group
//            * Exiting program
//            * Debug mode is also included execute program in cmd with "-d" flag
//                    when running under debug mode, group's information will be
//                    displayed as we the program traverses through the linked
//                    list showing status of each group prior to change
//
//            Thank you reviewing the code and have an GREAT DAY!
//


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define present  0
#define reserved 1


typedef enum {FALSE, TRUE} boolean;                         // for extra credits


typedef struct stack{
    char name[30];
    int size, status;
    struct stack* behind;
} group;


// sourceA
int main (int argc, char **argv);
void clearToEoln();
int getNextNWSChar ();
int getPosInt ();
char *getName();
void printCommands();

// sourceB
void doWaiting (group * stand, int debug);
void doCallAhead (group** stand, int debug);
void doAdd (group** stand, int debug);
void doRetrieve (group ** stand, int debug);
void doList (group* stand, int debug);
void doDisplay (group * stand);

// sourceC
void addToList(group ** stand, char* name, int size, int status, int debug);
boolean doesNameExist(group* stand, char* name, int debug);
boolean updateStatus(group* stand, char* name, int debug);
char * retrieveAndRemove (group** stand, int size, int debug);
int countGroupsAhead (group * stand, char * name );
void displayGroupSizeAhead (group* stand, char* name, int *inLine, int debug);
void displayListInformation(group* stand);
int debugCheck(int argc, char **argv);
group** goToEnd(group* stand);
void debugDisplay(group * stand);
boolean isLineEmpty(group * stand);
void doNothing (char ch);
void Title(int debug);
