
#include "jchoi215_proj4.h"


void doAdd (group** stand, int debug){

    int size = getPosInt();                   /* get group size from input */
    if (size < 1)
    {
      printf ("\n Error: Add command requires an integer value of at least 1\n");
      printf (" -----  Add command is of form: a <size> <name>\n");
      printf ("        <size> is the size of the group making the reservation\n");
      printf ("        <name> is the name of the group making the reservation\n\n");
      return;
    }

    char *name = getName();                   /* get group name from input */
    if (NULL == name)
    {
      printf ("\n Error: Add command requires a name to be given\n");
      printf (" -----  Add command is of form: a <size> <name>\n");
      printf ("        <size> is the size of the group making the reservation\n");
      printf ("        <name> is the name of the group making the reservation\n\n");
      return;
    }

    addToList(stand, name, size, present, debug);   // push values into que stack
}


void doCallAhead (group** stand, int debug){

    int size = getPosInt();                     /* get group size from input */
    if (size < 1)
    {
      printf ("\n Error: Call-ahead command requires an integer value of at least 1\n");
      printf (" -----  Call-ahead command is of form: c <size> <name>\n");
      printf ("        <size> is the size of the group making the reservation\n");
      printf ("        <name> is the name of the group making the reservation\n\n");
      return;
    }

    char *name = getName();                     /* get group name from input */
    if (NULL == name)
    {
      printf ("\n Error: Call-ahead command requires a name to be given\n");
      printf (" -----  Call-ahead command is of form: c <size> <name>\n");
      printf ("        <size> is the size of the group making the reservation\n");
      printf ("        <name> is the name of the group making the reservation\n\n");
      return;
    }

    addToList(stand, name, size, reserved, debug);      // push values into quest stack
}


void doWaiting (group * stand, int debug){

    char *name = getName();                            /* get group name from input */
    if (NULL == name)
    {
      printf ("\n Error: Waiting command requires a name to be given\n");
      printf (" -----  Waiting command is of form: w <name>\n");
      printf ("        <name> is the name of the group that is now waiting\n");
      return;
    }

    if(debug)
    {
      if(!stand) printf("\n   [ Currently list is empty ]");
      printf("\n");
    }

    if(doesNameExist(stand, name, debug))               // check if name exist if it
    {                                                   // does, check the status &
      (updateStatus(stand, name, debug))?                      // update and prompt
      printf ("\n   >> Waiting group \"%s\" is now in the restaurant [ updated ]\n", name) :
      printf ("\n   >> Group \"%s\" is already waiting in line\n", name);
    }
                                                          // if group is NOT found
    else printf ("\n   >> Group \"%s\" is NOT found in the waiting list... \n", name);
}


void doRetrieve (group ** stand, int debug){

    int size = getPosInt();                          /* get table size from input */

    if (size < 1){
      printf ("\n Error: Retrieve command requires an integer value of at least 1\n");
      printf (" -----  Retrieve command is of form: r <size>\n");
      printf ("        <size> is the size of the group making the reservation\n\n");
      return;
    }

    clearToEoln();

    if(debug)
    {
      printf("\n");
      displayListInformation(*stand);
    }
                                                   // check if the list is empty
    if( isLineEmpty(*stand) )   printf("\n  >> Line is currently unoccupied\n");
    else
    {                       //"service is provided" remove group from linked list
      printf ("\n\n Retrieve (and remove) the first group that can fit at a tabel of size [ %d ]\n", size);
      printf (" ----------------------------------------------------------------------------\n");
      printf (" %s\n\n", retrieveAndRemove(stand, size, debug) );
    }
}


void doList (group* stand, int debug){
    int i; int inLine = 0;
    char *name = getName();                     /* get group name from input */
    if (NULL == name){
        printf ("\n Error: List command requires a name to be given\n");
        printf (" -----  List command is of form: l <name>\n");
        printf ("        <name> is the name of the group to inquire about\n\n");
        return;
    }
    if (debug) printf("\n");
    if( doesNameExist(stand, name, debug) )       // check if group exist and
    {                                             // list out groups that are in
                                                  // front of a particular group
      int count = countGroupsAhead(stand, name);
      if(count != 0)
        {
          printf("\n\n Group \"%s\" is behind %d following group(s) \n ", name, count);
          int length = sizeof(name) / sizeof(char);
          for(i = 0; i < length; ++i) printf("=");
          printf("================================== \n\n");

          displayGroupSizeAhead(stand, name, &inLine, debug);
        }
      else printf("\n    >> Group \"%s\" is currently in front of the line\n", name);

    }
                                                   // if not found, prompt user
    else printf("\n    >> Group \"%s\" was not found in waiting list\n", name);
}


void doDisplay (group * stand){
    clearToEoln();                        // list the groups that are in line
    printf ("\n\n + ================================================ + \n");
    printf (    " |        Display information about group(s)        | \n");
    printf (    " + ================================================ + \n\n");
    if(!stand) printf("   [ Currently list is empty ]\n");
    displayListInformation(stand);
}
