
#include "jchoi215_proj4.h"


void clearToEoln(){
     int ch;             /* Clear input until next End of Line Character - \n */
     do { ch = getc(stdin);  }  while ((ch != '\n') && (ch != EOF));
 }


int getNextNWSChar (){

    int ch = getc(stdin);
    if (ch == EOF) return ch;

    while (isspace (ch))
    {
        ch = getc(stdin);
        if (ch == EOF) return ch;
    }
   return ch;
}


int getPosInt (){

    int value = 0;   int ch = getc(stdin);   /* clear white space characters */

    while (!isdigit(ch))
    {
        if ('\n' == ch)  return 0;           /* error \n ==> no integer given */
        if (!isspace(ch)){ clearToEoln();  return 0; }
        ch = getc(stdin);
    }

    value = ch - '0';
    ch = getc(stdin);

    while (isdigit(ch)){    value = value * 10 + ch - '0';    ch = getc(stdin);}

    ungetc (ch, stdin);   /* put the last read character back in input stream */

    if (0 == value) clearToEoln();                 /* value of 0 is an error  */
    return value;
}


char *getName(){

    int ch, i;     int size = 10;      int count = 0;        char *word;

    ch = getc(stdin);                    /* skip over the white space characters */
    while (isspace(ch))
     {
        if ('\n' == ch) return NULL;           /* error \n ==> no integer given */
        ch = getc(stdin);
     }

    word = (char *) malloc (sizeof(char) * size);

    while (ch != '\n')        // read in character-by-character until the newline
    {
        if (count+1 >= size){
             char* temp;                       // dynamically sized" grow an array
             size = size * 2;
             temp = (char *) malloc (sizeof(char) * size);

             for (i = 0 ; i < count ; i++) temp[i] = word[i]; // transfer to new

             free (word);
             word = temp;
          }

        word[count] = ch;  count++;  word[count] = '\0';

        ch = getc(stdin);                                   // read next character
    }
    if (count > 30){ count = 30;   word[count] = '\0';  }

    /* clear ending white space characters */
    while (isspace (word[count-1])){  count--;   word[count] = '\0';  }

    return word;
}


void printCommands(){
    printf ("\n\n + ================================================ +\n");
    printf (    " |         The commands for this program are:       |\n");
    printf (    " + ================================================ +\n\n");
    printf (" q - to quit the program\n");         /* Print commands for  program */
    printf (" ? - to list the accepted commands\n");
    printf (" a <size> <name> - to add a group to the wait list\n");
    printf (" c <size> <name> - to add a call-ahead group to the wait list\n");
    printf (" w <name> - to specify a call-ahead group is now waiting in the restaurant\n");
    printf (" r <table-size> - to retrieve the first waiting group that can fit at the available table size\n");
    printf (" l <name> - list how many groups are ahead of the named group\n");
    printf (" d - display the wait list information\n\n");

    clearToEoln();                                 /* clear input to End of Line */
}


int main (int argc, char **argv){

    int ch;      char *input;      int debug = debugCheck(argc, argv);

    Title(debug);

    printf ("\n Enter command: ");

    group *stand = NULL;
    while ((ch = getNextNWSChar ()) != EOF)
    {
        printf(" -------------\n");
        if       ('q' == ch){  printf ("\n   >> Quitting Program\n\n");   return(0);}
        else if  ('?' == ch)   printCommands();
        else if  ('a' == ch)   doAdd(&stand, debug);
        else if  ('c' == ch)   doCallAhead(&stand, debug);
        else if  ('w' == ch)   doWaiting(stand, debug);
        else if  ('r' == ch)   doRetrieve(&stand, debug);
        else if  ('l' == ch)   doList(stand, debug);
        else if  ('d' == ch)   doDisplay(stand);       //Debug is NOT applicable
        else                   doNothing(ch);
                                                               // r l gets debug
        printf (" \n Enter command: ");
     }

    printf (" Quiting Program - EOF reached\n");
    return 1;
}
