

#include "jchoi215_proj4.h"


void addToList(group ** stand, char* name, int size, int status, int debug){


      if(debug){ printf("\n");  if(*stand == NULL) printf(" [ List is empty ]\n");}

      if( doesNameExist(*stand, name, debug) )   // check of name already exist
      {
         printf ("\n Error: Name \"%s\" already exist in the records\n", name);
         printf (" -----  Please re-input command with a different Name\n\n");
         return;
      };


      group* temp = (group*)malloc(sizeof(group));       // allocate memory for
      temp->behind = NULL;      temp->size = size;       // linked list & store
      strcpy(temp->name, name);                          // data.


      if(status == reserved)                             // depending on status
      {                                                  // store & prompt
          printf ("\n    >> Call-ahead group \"%s\" of size %d\n", name, size);
          temp->status = reserved;
      }

      if(status == present )
      {
          printf ("\n    >> Adding group \"%s\" of size %d \n", name, size);
          temp->status = present;
      }


      if(*stand == NULL) *stand = temp;  // if list NULL, make temp as new head
      else{   group ** position = goToEnd(*stand);     *position = temp; }
}

boolean doesNameExist(group* stand, char* name, int debug){

    while(stand != NULL )                   // sort through the linked list and
    {                                       // check to see if it is found
        if(debug) debugDisplay(stand);
        if(strcmp(stand->name, name) == 0) return TRUE;
        stand = stand->behind;              // move linked list position along
    }
    return FALSE;
}

boolean updateStatus(group* stand, char* name, int debug){

    if(debug) printf("\n");

    while(stand)               // check linked list to see the status of a group
    {                          // if it happens to be waiting in line return

        if(strcmp(stand->name, name) == 0)           // false, other wise it was
        {                                            // called ahead, update &
            if   ( stand->status == present) return FALSE;       // return true
            else { stand->status =  present; return TRUE; }
        }
        stand = stand->behind;                          // keep list going till

    }                                                   // condition is met
    return FALSE;
}

char * retrieveAndRemove (group** stand, int size, int debug){

    char * servingGroup;
    boolean served = FALSE;
    group * front = (*stand);
    group * back  = (*stand)->behind;


    if( ((*stand)->size <= size) && (*stand)->status == present && !((*stand)->behind))
    {
        served = TRUE;
        servingGroup = (char *)malloc( (sizeof( (*stand)->name ) +1) *  sizeof(char));
        strcpy(servingGroup, (*stand)->name);
        free  (*stand);  *stand = NULL;            // 1st one && only one in list
        printf("\n  >> Now serving group:");          // pop/free and set to null
        return servingGroup;
    }


   while(back){

         if( ((*stand)->size <= size) && (*stand)->status == present )
         {
             served = TRUE;
             servingGroup = (char *)malloc( (sizeof( (*stand)->name ) +1) *  sizeof(char));
             strcpy(servingGroup, (*stand)->name);
             group * temp = *stand;                         // 1nd one && more in list
             *stand = (*stand)->behind;                       //  move to next node,
             free  (temp);                                       // pop/free 1st one
             printf("\n  >> Now serving group:");
             return servingGroup;
         }


        else if( (back->size <= size) && back->status == present && !(back->behind))
        {
          served = TRUE;
          servingGroup = (char *)malloc( (sizeof(back->name) +1) *  sizeof(char));
          strcpy(servingGroup, back->name);
          free (back);  front->behind = NULL;           // at end of list, pop /
          printf("\n  >> Now serving group:");               // free the last, one
          return servingGroup;                          // prior is edge is set
        }                                               // to NULL

        else if ( (back->size <= size) && back->status == present && back->behind)
        {
          served = TRUE;
          servingGroup = (char *)malloc( (sizeof(back->name) +1) *  sizeof(char));
          strcpy(servingGroup, back->name);
          front->behind = back->behind;              // middle of linked list
          free (back);                               // create proper connection
          printf("\n  >> Now serving group:");            // then free the node
          return servingGroup;
        }

        else  back = back->behind; front = front->behind;    // keep them moving

   }

    if(!served)                             // if no service was provided prompt
    {
        servingGroup = (char*) malloc ( 70 * sizeof(char));
        strcpy(servingGroup, "\n   [ Insufficient tables or clients are not present at this time ]\n");
        return servingGroup;
    }
}

int countGroupsAhead (group * stand, char * name ){
    int count = 0;

    while(strcmp(stand->name, name) != 0)        // loop and count the number of
    {                                            // groups that are in front of
      ++count;                                   // a certain group & return
      stand = stand->behind;                     // counted value
    }

    return count;
}

void displayGroupSizeAhead (group* stand, char* name, int *inLine, int debug){

     if(debug) printf("\n");

     while(strcmp(stand->name, name) != 0)      // list groups that are in front
     {                                          // of a particular group
         ++*inLine;
         if(debug) debugDisplay(stand);
         else printf(" Group %2d: \"%s\"\n", *inLine, stand->name);
         stand = stand->behind;
     }

     if(debug) debugDisplay(stand);
}

void displayListInformation(group* stand){

    if(!stand) return;                                       // if NULL return

    else                                                     // display status
    {
       if(stand->status == reserved) printf(" [ Reserved ]\n");
  else if(stand->status == present)  printf(" [ Waiting in line ]\n");

        printf(" Group Name: %s\n", stand->name);         // display group name
        printf(" Group Size: %d\n\n", stand->size);       // display group size

        displayListInformation(stand->behind);  // display groups that are ahead
    }
}

int debugCheck(int argc, char **argv){
    int i;                                 // check if debug mode flag is given
    for(i = 0; i < argc; ++i)  if(strcmp(argv[i], "-d") == 0)  return TRUE;
    return FALSE;
}

group** goToEnd(group* stand){
    if(stand->behind == NULL) return &stand->behind; // get to end of node
    else goToEnd(stand->behind);                     // and return it for malloc
}

void debugDisplay(group * stand){
    (!stand->status)?
    printf(" [ waiting in line ]\n") : printf(" [ Reserved ] \n");
    printf( " Group Name: \"%s\"\n Group size: %d \n\n", stand->name, stand->size);
}

boolean isLineEmpty(group * stand){
    while(stand)                             // quick check to see if there is a
    {                                        // group waiting in line, reservation

      if(!stand->status) return FALSE;       // does NOT count as being in LINE
      stand = stand->behind;
    }
    return TRUE;
}

void doNothing (char ch){
     // when invalid command is taken in, provide suggestions on how to use the
     printf ("\n Error: %c - in not a valid command\n", ch);        // program
     printf (" -----  For a list of valid commands, type ?\n\n");
     clearToEoln();
}

void Title(int debug){
                                                               // display header
            printf (" \n\n");
            printf (" + ================================================ +\n");
  if(debug) printf (" |                  DEBUG MODE ACTIVE               |\n");
            printf (" |       Starting Restaurant Wait List Program      |\n");
            printf (" + ================================================ +\n");
}
