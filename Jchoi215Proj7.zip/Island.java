import java.awt.*;

class Island
{
	// needed variables for the program
	private GridDisplay disp;
	private Creature[][] grid;
	private int days;
	private int row;
	private int col;
	private int aCount;
	private int dCount;
	private int total;
	private int space;
  

	// when creating island set under these conditions
	public Island (int row, int col)
	{
		this.row = row;
		this.col = col;
		aCount = 0;
		dCount = 0;
		space = row * col;

		// create grid and 2D colorful background
		disp = new GridDisplay(row, col);   
		grid = new Creature[row][col];


		// start out by having with grid all set to null
		for (int i = 0 ; i < row ; i++) 
		for (int j = 0 ; j < col ; j++)
		grid[i][j] = null;

		days = 0;	// day count is set to 0
	}



	public void nextDay()
	{
		// start of new day, increase day
		days++;          


		// reset all movement for all the insect from previous day
		for (int i = 0 ; i < row ; i++)     
		for (int j = 0 ; j < col ; j++)
		if(grid[i][j] != null)
		{
			Creature thisInsect = grid[i][j];
			thisInsect.resetMove();
		}


		// 1st do all doodlebug actions
		for (int i = 0 ; i < row ; i++) 
		for (int j = 0 ; j < col ; j++)
		if(grid[i][j] != null)
		{
			Creature thisInsect = grid[i][j];
			
			// looking for doodlebugs
			if(thisInsect.getType() == 2)
			{
				// check if the doodlebug hsa moved
				if(!thisInsect.hasMoved())
				{
					Doodlebug dBug = (Doodlebug)grid[i][j];

					if( dBug.Hunt() )       // 1st do hunt
					{
						dBug.Ate();         // since it found food reset 
					}                       // starvation count
					else
					{
						dBug.Wonder();      // failed to hunt, now it will wonder
						dBug.GoneHungry();  // increase days starved
					} 

					int age = dBug.getAge(); // retrieve the bug's age
					
					// check to see if doodlebug is ready to spawn or holding an egg
					if( (age % dBug.spawnRate() == 0 && age != 0) || dBug.checkIfWithEgg() )
					{
						dBug.Spawn();        // doodle bug spawn another doodlebug					
					} 
					
					// check if doodlebug starved for 3 days, if yes -> death
					if(dBug.checkDaysStarved() >= dBug.getDeathRate())
					{
						dBug.starvedToDeath();
					} 
					
					dBug.setMoved();         // this doodle bug cannot move again for this turn
					dBug.getOlder();         // increase the age opf the doodlebug
				}
			}
		}



		// 2nd do all the ants actions  ** pretty much the same as doodlebug w/ less actions
		for (int i = 0 ; i < row ; i++) 
		for (int j = 0 ; j < col ; j++)
		if(grid[i][j] != null)               
		{
			Creature thisInsect = grid[i][j];
			if(thisInsect.getType() == 1)
			{
				if(!thisInsect.hasMoved())
				{
					Ant ant = (Ant)grid[i][j];
					
					ant.Wonder();
					
					int age = ant.getAge();
					if( (age % ant.spawnRate() == 0 && age != 0) || ant.checkIfWithEgg() )
					{
						ant.Spawn();
					} 

					ant.setMoved();
					ant.getOlder();
				}
			}
		}
	}




	public boolean moveInsect (int currX, int currY, int nextX, int nextY, int type, boolean justMoving)
	{
		if(justMoving)    // if this used for just moving check these conditions
		{
			if ( invalidBoundary(currX, currY) ) return false;
			if ( invalidBoundary(nextX, nextY) ) return false;
			if ( isValidPlacement(nextX, nextY) != true )  return false;			
		}
		else aCount-=1;   // since it was used for hunt, and ant is eaten

		grid[nextX][nextY] = grid[currX][currY];  // move insect from one place to another
		grid[currX][currY] = null;                // set his old place to be null


		// set proper color based on what kind of insect it is.
		if(type == 1)                              
		  disp.setColor(nextX,nextY, Color.BLACK); 
		if(type == 2)
		  disp.setColor(nextX,nextY, Color.RED);

		// delete his old placement from color grid
		disp.setColor(currX,currY, Color.WHITE);

		// return true when move was successful
		return true; 
	}



	public void createAnt (Ant bug, int x, int y)
	{
		// used to create Ant and mark it's place in the grid + increase ant count
		disp.setColor (x, y, Color.BLACK);
		grid[x][y] = bug;
		aCount += 1;
	}

	public void createDoodlebug (Doodlebug bug, int x, int y)
	{
		// used to create doodlebug, mark it's place + increase doodlebug count
		disp.setColor (x, y, Color.RED);
		grid[x][y] = bug;
		dCount +=1;
	}



	public boolean invalidBoundary(int x, int y)
	{
		// return false when position is out of bounce
		if (x < 0 || x >= row || y < 0 || y >= col) return true;
		return false;
	}



	public boolean isValidPlacement(int x, int y)
	{
		// if place is empty return true 
		if( grid[x][y] == null) return true; 
		return false; 
	}


	public void death(int x, int y)
	{
		// kill off doodlebug + decrease number count of doodlebug
		dCount-=1;
		grid[x][y] = null;
		disp.setColor(x,y, Color.WHITE);
	}


	public boolean enoughSpace()
	{
		// check if there are enough spoace
		if(space >= (aCount + dCount) ) return true; 
		else return false; 
	}

	

	// getters and setters to take in / take out values
	public int getDay()    { return days;}
	public int getRows()   { return row; } 
	public int getCols()   { return col; }
	public int getACount() { return aCount; }
	public int getDCount() { return dCount; }
	public int randX()     { return (int)(Math.random() * row ); }
	public int randY()     { return (int)(Math.random() * col ); }
	public Creature retrieveInsect(int x, int y) {return grid[x][y]; }

}