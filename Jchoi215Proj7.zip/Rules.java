class Rules
{
	// for Grid size
	public static final int SIZE_X = 20;
	public static final int SIZE_Y = 20;

	// number of insects at start
	public static final int ANT = 100;
	public static final int DOODLEBUG = 5;
	
	public static final int STANDARD_FRAME_RATE = 100;
	
}