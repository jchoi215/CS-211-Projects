class Doodlebug extends Creature
{
  Island island;
  private int deathRate;
  private int daysStarved;

  // create doodlebug under default conditions
  public Doodlebug(Island island, int x, int y) 
  {
    // access Creature class and create the core of insect
    super(island, 8, 2, x, y);    
    this.island = island;
    daysStarved = 0;
    deathRate = 3;
    island.createDoodlebug(this, super.getX(), super.getY());
  } 



  public boolean Hunt()
  {	
    // retrieve the doodlebug position
    int x = super.getX();
    int y = super.getY();

    // using stack, to randomly select ant to kill off
    Stack attackMarker = new Stack();
    int[] moveX = new int[8];
    int[] moveY = new int[8];

    moveX[0] = x;   moveY[0] = y-1;
    moveX[1] = x;   moveY[1] = y+1;
    moveX[2] = x-1; moveY[2] = y;  
    moveX[3] = x+1; moveY[3] = y;  
    moveX[4] = x+1; moveY[4] = y+1;
    moveX[5] = x+1; moveY[5] = y-1;
    moveX[6] = x-1; moveY[6] = y+1;
    moveX[7] = x-1; moveY[7] = y-1;


    for(int i = 0; i < 8; i++)
    {
      // for checking process, 1st check if position is valid
      if( !island.invalidBoundary(moveX[i], moveY[i]) )
      {
        // if yes, get the information in that grid position
        int xPos =  moveX[i];
        int yPos =  moveY[i]; 
        Creature bug = island.retrieveInsect(xPos,yPos);

        // check if there is insect there
        if(bug != null)
        {
          // check to make sure it is ant, if so push on to stack
          if(bug.getType() == 1) attackMarker.push(moveX[i], moveY[i]);
        }
      } 
    }

    // check how many ants are around the doodlebug
    int numAnts = attackMarker.getCount();

    // if there is an ant next to doodlebug
    if( numAnts > 0)
    {
      // randomly select the ant position
      int randPick  = (int)(Math.random() * numAnts +1);

      Node target = new Node();
      for(int i = 0; i < randPick; i++)  target = attackMarker.pop();

      // retrieve random position of that ANT
      int targX = target.getX();  
      int targY = target.getY();

      // move the doodlebug to that ant
      island.moveInsect(x, y, targX, targY, 2, false);
      
      // set x and y position
      super.setX(targX);
      super.setY(targY);
      return true;
    }

    return false;
  }

  // getters and setters
  public int getDeathRate(){return deathRate;}
  public int checkDaysStarved(){return daysStarved; }
  public void Ate(){daysStarved = 0; }
  public void GoneHungry(){ daysStarved++; }
  public void starvedToDeath() { island.death(super.getX(), super.getY()); }
}


