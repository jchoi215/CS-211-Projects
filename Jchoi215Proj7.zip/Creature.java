

// parent class that will be used for ant and doodlebug class
class Creature
{
  private Island island;         
  private int x;              
  private int y;
  private int type;     
  private int age;
  private int rate;
  private boolean withEgg;
  private boolean moved;

  // create creature under these default settings
  public Creature (Island island, int rate, int type, int x, int y)
  {
    this.island = island;
    this.rate   = rate;
    this.type   = type;
    this.x = x;
    this.y = y;

    withEgg = false;
    moved = true;
    age = 0;
  }


  public void Wonder ()
  {
    int nextX = -999;
    int nextY = -999;

    // select a random direct to move toward
    int direction = (int)(Math.random() * 4);

    if     (direction == 0){ nextX = x;   nextY = y-1; }
    else if(direction == 1){ nextX = x;   nextY = y+1; }
    else if(direction == 2){ nextX = x-1; nextY = y;   }
    else if(direction == 3){ nextX = x+1; nextY = y;   }

    // if randomly selected direction, is valid, it will move the new position
    if ( island.moveInsect ( x, y, nextX, nextY , type, true) == true) { x = nextX; y = nextY; } 
  }




  public void Spawn()
  {
    // create a stack
    Stack spawnPoint = new Stack();
    int[] spawnX = new int[8];
    int[] spawnY = new int[8];


    // set in all the directions into array
    spawnX[0] = x;   spawnY[0] = y-1;
    spawnX[1] = x;   spawnY[1] = y+1;
    spawnX[2] = x-1; spawnY[2] = y;  
    spawnX[3] = x+1; spawnY[3] = y;  
    spawnX[4] = x+1; spawnY[4] = y+1;
    spawnX[5] = x+1; spawnY[5] = y-1;
    spawnX[6] = x-1; spawnY[6] = y+1;
    spawnX[7] = x-1; spawnY[7] = y-1;


    // loop and check if that place is empty to spawn
    for(int i = 0; i < 8; i++)
    {
      // check if that position is valid position in the boundary
      if( !island.invalidBoundary(spawnX[i], spawnY[i]) )
      {
        int xPos =  spawnX[i];
        int yPos =  spawnY[i]; 
       
        // if yes, get the information in that grid position
        Creature bug = island.retrieveInsect(xPos,yPos);

        // check if that spot is empty
        if(bug == null) spawnPoint.push(spawnX[i], spawnY[i]);
      } 
    }

    // check how many spots are empty
    int nSpots = spawnPoint.getCount();
    
    // if there is an empty place
    if( nSpots > 0)
    {
      // randomly select random number to pop stack
      int randPick  = (int)(Math.random() * nSpots +1);

      Node openSpot = new Node();
      for(int i = 0; i < randPick; i++)  openSpot = spawnPoint.pop();

      // empty position x and y
      int openX = openSpot.getX();  
      int openY = openSpot.getY();

      // create an insect depending on the type 
      Ant new_Ant;
      Doodlebug new_dBug;
      if(type == 1) new_Ant = new Ant(island, openX, openY);
      else if(type == 2) new_dBug = new Doodlebug(island, openX, openY);        

    }
    else withEgg = true;  // if all positions are full and have to spawn

  }


  // getters and setters that will be used to exchange information
  public int  getX(){return x;}
  public int  getY(){return y;}
  public int  getAge(){return age;}
  public int  getType(){return type;}
  public int  spawnRate(){return rate;}
 
  public void setX(int posX){x = posX;}
  public void setY(int posY){y = posY;}
  public void getOlder(){ age++; }
  public void holdingEgg(){withEgg = true;}
  public void resetMove(){moved = false;}
  public void setMoved(){moved = true;} 
  
  public boolean hasMoved(){return moved;}
  public boolean checkIfWithEgg(){return withEgg;}
  public Island getIsland(){return island; }
}