class Ant extends Creature
{
  public Ant(Island island, int x, int y) 
  { 
  	// create Ant, with parent Creature class
  	// the values being passed are: location / rate of spawn / type / position x & y
    super(island, 3, 1, x, y); 
    island.createAnt(this, super.getX(), super.getY());     
  } 
}


