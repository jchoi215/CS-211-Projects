

// NAME:  JAE RIM CHOI
// NetID: jchoi215
// Project 7: Ant and Doodlebug simulation

//  ======================
//	Features being tested:
//  ======================
//
//  Purpose of this program is to simulate the rate of	
//  Ants being spawned vs rate at which doodle bug eats
//  the ants, attempting to show the relationship between
//  the two given insects.
//
//  -- Ant spawn every 3 days
//  -- Doodlebug spawn every 8 days, however dies if has not eaten an ant within the last 3 days.
//  
// 
//  Debug mode:
//  -----------
//     
//  when given -d commandline arguement, along with frame rate speed
//  it makes the proper changes to allow the system to run under those settings 
//  in addition to displaying the [ day  / ant count / doodlebug count] of each day.
//   
//  Rule.java can be changed to allow for the changes below without changing the code in here
//  -----------------------------------------------------------------------------------------
//
//   -- changes to grid size
//   -- changes to ant and doodlebug count at the start of simulation
//   -- changes to default frame rate
//  
//


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class Jchoi215Proj7 extends Rules
{

	// global variable for debuggin
	private static boolean DEBUG = false;                              


	public static void main (String[] args)
	{    
		boolean error;

		// create island (row x col)
		Island island = new Island(SIZE_X, SIZE_Y);
		
		// set frame rate
		int frameRate = isDebug(args);
		
		// display title to screen
		Title (frameRate);


		// attempt to place insect, return false if grid is full.
		error = PlaceThisCreature (island, ANT, 1);
		if(!error)
		error = PlaceThisCreature (island, DOODLEBUG, 2);
		if(!error) // if no error - >Display that it was a success
		System.out.println("Insect initialization...     [success]\n");


		if(!error) RunSimulation(island, frameRate); // without error RUN 
		else	   ExitSimulation();                 // with error exit
		System.exit(0);                              // close program 
	}





	public static void ExitSimulation()
	{
		// prompt user that there was error
		System.out.println("\n[ERROR: INSUFFICIENT SPACE IN 2D GRID]\n");
		System.out.println(  "            Exiting program            \n");
	}




	public static void RunSimulation(Island island, int frameRate)
	{
		// these are use to mark Extiction dates of certain insect
		boolean antExtinction = false;
		boolean dooExtinction = false;

		int ant_extinction_date = 0;
		int doo_extinction_date = 0;
		
		// max insect count of the island
		int maxInhabitant = SIZE_X * SIZE_Y;

		while( (island.getACount() != 0 && island.getACount() != maxInhabitant) || island.getDCount() != 0)
		{
			int day = island.getDay();
			int ant_count = island.getACount();
			int doo_count = island.getDCount();
			
			if(DEBUG)
			{   // show: day / ant count / doodlebug count
				dDisplay( day, ant_count, doo_count );  
			} 
			
			if( day != 0 && ant_count == 0 && !antExtinction)
			{   // record day when ants have gone extinct
				ant_extinction_date = day; 
				antExtinction = true;
			} 

			if( day != 0 && doo_count == 0 && !dooExtinction)
			{   // record day when doodlebug have gone extinct
				doo_extinction_date = day; 
				dooExtinction = true;
			} 
			

			GridDisplay.mySleep ( frameRate );  // slow it down
			island.nextDay();                   // go to next day
		}


		int followingDay = island.getDay() + 1;
		if (DEBUG) dDisplay( followingDay, island.getACount(), island.getDCount() );

		// prompt user result
		System.out.println("\n          Result of Experiment          "); 
		System.out.println(  "======================================= ");


		// if both insect types went extinct show this prompt
		if(island.getACount() == 0 && island.getDCount() == 0)
		{
			System.out.println("\n Day "+ ant_extinction_date +", all the ants were eaten alive."); 
			System.out.println(" As result, on day " + followingDay + " all the doodlebugs");
			System.out.println(" died from starvation."); 
		} 	

		// if just doodlebug went extinct show this prompt
		else		
		{
			System.out.println("\n Day "+ doo_extinction_date +", all the Doodlebugs died from");
			System.out.println( " starvation. As result, ants flourished ");
			System.out.println( " and reached max insect count on day " + followingDay +"."); 			
		}
	}



	public static boolean PlaceThisCreature (Island island, int numInsect, int insectType)
	{
		// loop x number times, randomly selecting a position place the insect
		for (int i = 0 ; i < numInsect;  i++)    
   	 
			// check to see if there is space in for the insect to be placed
			if( island.enoughSpace() )    
			{
				int x = island.randX();
				int y = island.randY();
				
				// create a selected insect inside the island
				if(insectType == 1)
				{
					Ant a;
					if(island.isValidPlacement(x,y)) a = new Ant(island, x, y);
					else i--;           // Loop again, when it hit another insect
				}
				else
				{
					Doodlebug d;
					if(island.isValidPlacement(x,y)) d = new Doodlebug(island, x, y);
					else i--;
				}

			} 
			else return  true;

		return false;
	}



	public static void Title(int frameRate)
	{   
		// Display the title and island status
		System.out.println("\n======================================= ");
		System.out.println(  "*       Doodlebugs VS Ants            * ");
		System.out.println(  "======================================= ");

		// if under  DEBUG mode show different prompt
		if(DEBUG) System.out.println(  "Simulation under [ DEBUG ] mode  ");
		else      System.out.println(  "Simulation under [ Default ] mode");
		
		System.out.println(  "Island size: " + SIZE_X + "x" + SIZE_Y);
		System.out.println(  "Frame rate: " + frameRate + "\n");
		System.out.println(  "\n    Attempting to initialize insects ");
		System.out.println(  "======================================= ");
		System.out.println(  "Ants: " + ANT);
		System.out.println(  "Doodlebugs: " + DOODLEBUG );
	}




	public static void dDisplay(int day, int aCount, int dCount)
	{
		// when under debug mode show day / ant count / doodlebug count
		System.out.println("Day: " + day);
		System.out.println("Ant Count: " + aCount + "\nDoodlebug Count: " + dCount+"\n");
	}



	public static int isDebug(String[] args)
	{	
		// checking commandline argument for the program
		switch(args.length)
		{
			case 0: break;                 // no argument is given
			case 2:           
					String flag  = "-d";   // checking for searching argument
					if( flag.equals(args[0]) )            // -d was  accepted
					{
						try     
						{
							// check if the value is positive & greater than 0
							int val = Integer.parseInt( args[1] );     
							if(val > 0)
							{
								DEBUG = true;       // when both conditions
								return val;         // are met DEBUG turn on debug
							}                       // return new frame rate to main
							else Error_Prompt();    // if it happens to be negitive turn on default

						}
						catch( NumberFormatException nfe)   // in case when 2nd argument is INVALID
						{
							Error_Prompt();		
						}

					}
					else  Error_Prompt();		
					break;
			
			default:
					Error_Prompt();	        // any other argument length are invalid
					break;
		}
		return STANDARD_FRAME_RATE;         // when it's invalid, return set default rate
	}



	public static void Error_Prompt()
	{   // prompt when invalid commandline arguement are taken in 
		System.out.println("\n ** Invalid command line arguement (Default: ON) ** \n");
	}

}

