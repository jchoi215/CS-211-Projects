class Stack
{
	private Node head;
	private int count;

	// create stack under these default conditions
	public void Stack()
	{	
		head  = null;	
		count = 0;
	} 	
	
	// return head 
	public Node getHead(){ return head; }
	
	// create and push to stack
	public void  push(int x, int y)
	{
		Node temp = new Node();
		temp.setXY(x,y);
		temp.setNext(head);
		head = temp;
		count++;
	}

	//  pop from stack
	public Node pop()
	{
		Node temp = head;
		head = head.getNext();
		--count;
		return temp;
	}

	// check how many node are in stack
	public int getCount(){return count; }

}


class Node
{
	// storing x and y positions
	private int x;
	private int y;
	private Node next;

	// getter functions to retrieve data
	public int getX() {return x; } 
	public int getY() {return y; }
	public void setNext(Node n) {next = n; } 
	public Node getNext() {return next; }
	public void setXY(int valX, int valY){ x = valX; y = valY; }
}