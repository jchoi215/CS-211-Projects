//  Programming Project 3
//
//  NetID: jchoi215
//  Name: Jae Rim Choi
//  Enviroment: windows 10,  text editior: Atom   compiler: gcc compiler
//
//  Summmery: program that reads from list of ACCEPTED text files creats a maze
//             and finds the path from start to end of the Maze using
//             depth first search.
//
//  ADDED FEATURE: Program can run multiple files as long as it is a valid file
//


#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

typedef struct mazeStruct{
    int row, col , Sx, Sy, Ex, Ey;
} maze;
typedef struct List{
    int xPos, yPos;
    struct List * prev;
}List;



void displayMaze(char *theMaze[], maze setMaze, int debug, bool prompt){
    int i, j;
                                                 // fix print so make it proper
    printf("\n  ");
    for(i = 0; i < setMaze.col +2; ++i) printf("*");

    //  just a tag to show what is what -- bit like legend
    (prompt)? printf(" \'v\' marks visited path \n") : printf("    ORIGINAL MAZE \n");

    // DISPLAY THE ACTUAL MAZE TO THE SCREEN
    for (i = 0; i <  setMaze.row; ++i)
    {
        printf("  *");
        for (j = 0; j < setMaze.col; ++j)
        {
            printf("%c",theMaze[i][j]);
        }
        printf("*\n");
    }
    printf("  ");                                // fix print so make it proper
    for(i = 0; i < setMaze.col +2; ++i) printf("*");printf("\n\n");
}


void errorPrompt(bool Disclaimer){

    if(!Disclaimer)   // when none of the file match valid file name -- close it
    {
      printf("\n\n STANDARD ERROR\n\n");  exit(-1);
    }
    else
    {     // in case there exist -- file which CANNOT create a valid maze
          printf("\n"                                                );
          printf("        MAZE cound NOT be created due to:     \n" );
          printf("        INVALID SIZE, START, END POSITION    \n\n" );
          printf("  --------------- DISCLAIMER ------------------\n" );
          printf("  This program was purposely designed to allow \n" );
          printf("  the program to CONTINUE instead of shutting  \n" );
          printf("  down when dealing in INVALID inputs as trade \n" );
          printf("  off allowing for the program to do multiple  \n" );
          printf("  maze search in a single run. As long as there\n" );
          printf("  is a file that matches name of intended files\n" );
          printf("  it will generate a solution to the maze.     \n\n" );
          printf("  I do understand the criteria but felt that   \n" );
          printf("  this would be the \"good solution\" that the \n" );
          printf("  professor suggested in his project guild lines.\n" );
          printf("  Thank you for your understanding.            \n\n" );
      }
}


bool isDebug(int argc, char** argv){
    int i;                               // check cmd argument if there is flag
    for (i = 0; i < argc; i++) if (strcmp("-d", argv[i]) == 0) return true;
    return false;
}


int multipath(int x, int y, char *theMaze[], maze setMaze){
    bool up    = false;
    bool down  = false;
    bool left  = false;
    bool right = false;
                                          // check to see path is blocked
    if(x + 1 < setMaze.col)
        if(theMaze[y][x+1] != 'v' && theMaze[y][x+1] != '*') right = true;

    if(x - 1 > 0)
        if(theMaze[y][x-1] != 'v' && theMaze[y][x-1] != '*') left  = true;

    if(y + 1 < setMaze.row)
        if(theMaze[y+1][x] != 'v' && theMaze[y+1][x] != '*') up    = true;

    if(y - 1 > 0)
        if(theMaze[y-1][x] != 'v' && theMaze[y-1][x] != '*') down = true;

    int path = right + left + up + down;     // count number of open paths

    return path;                             // return counted path
}


bool backTrack(int *curX, int *curY, List ** trail){
    List * oldTrail = *trail;                     // hold on to stack top
    if((*trail)->prev == NULL) return true;       // if list is empty return
    else *trail = (*trail)->prev;                 // move to one prior to top
    free(oldTrail);                               // free/pop the top
    *curX = (*trail)->xPos;                       // update scout position x,y
    *curY = (*trail)->yPos;
    return false;
}


void record(int x, int y, List ** trail, char *theMaze[], maze setMaze, bool debug){

    theMaze[y][x] = 'v';                              // mark as visited
    // if debug mode -> show position that is being pushed
    if(debug) printf("  PUSH: [%2d,%2d]\n",x, y);

    List * temp = (List *)malloc(sizeof(List));  // allocate new space for stack
    temp->xPos = x;
    temp->yPos = y;
    temp->prev = NULL;

    if(*trail == NULL)  *trail = temp;         // if list is empty
    else
    {
      temp->prev = *trail;                     // attach the list
      *trail = temp;
    }

}


void updatePosition(int x, int y, int *oriX, int *oriY){
    *oriX = x;     // update x and y position
    *oriY = y;
}


int move(int x, int y, char* theMaze[], maze setMaze, int *oriX, int* oriY, List ** trail, bool debug){
    // CHECK if position is with in bounds of the maze
    if(((0 <= x) && (x < setMaze.col)) && ((0 <= y) && (y < setMaze.row))){
          if(theMaze[y][x] != 'v' && theMaze[y][x] != '*') // check if is blocked
          {   // push the new position onto stack && update positon
              record(x, y, trail, theMaze, setMaze, debug);
              updatePosition(x,y,oriX, oriY);
              if(y == setMaze.Ey && x == setMaze.Ex) return 2; // if at END pos
              return 1;
          }
      }
      return 0;
}


 bool _reportHelper(int report){
     if(report == 0) return true;
     else return false;
 }


 bool sendScout(char *theMaze[], maze setMaze, List ** trail, bool debug){

      int report;
      int curX = setMaze.Sx;
      int curY = setMaze.Sy;
      bool dirChange  = true;
      bool solution   = false;
      bool failSearch = false;

      record(curX, curY, trail, theMaze, setMaze, debug);     // push to stack

      while(!failSearch)
      {
          if(multipath(curX, curY, theMaze, setMaze) == 0)//if there are NO path
          {                          // print the position which is being popped
              if(debug) printf("  pop:  [%2d,%2d]\n",curY, curX);
              failSearch = backTrack(&curX,&curY,trail); // POP BACK to PREVIOUS
          }

          // regarding report => solution found == BREAK  else == keep searching
          if(dirChange)
          {   // GO RIGHT and see if valid --
              report = move(curX+1,curY, theMaze, setMaze, &curX, &curY, trail, debug);
              if(report == 0 || report == 1) dirChange = _reportHelper(report);
              else { solution = true; break;}
          }
          if(dirChange)
          {   // GO DOWN and see if valid  --
              report = move(curX,curY+1, theMaze, setMaze, &curX, &curY, trail, debug);
              if(report == 0 || report == 1) dirChange = _reportHelper(report);
              else { solution = true; break;}
          }
          if(dirChange)
          {   // GO LEFT and see if valid --
              report = move(curX-1,curY, theMaze, setMaze, &curX, &curY, trail, debug);
              if(report == 0 || report == 1) dirChange = _reportHelper(report);
              else { solution = true; break;}
          }
          if(dirChange)
          {   // GO UP and see if valid   --
              report = move(curX,curY-1, theMaze, setMaze, &curX, &curY, trail, debug);
              if(report == 0 || report == 1) dirChange = _reportHelper(report);
              else { solution = true; break;}
          }
          dirChange = true;
    }

    return solution;
 }


void checkWall(int yTemp, int xTemp, maze* setMaze, char *theMaze[], bool debug){

    if(setMaze->row < yTemp || 1 > yTemp){       // print if wall row is INVALID
      if(debug)
      printf("  Invalid: row %d is outside range from 1 to %d\n",yTemp,setMaze->row);
    }
    else if(setMaze->col < xTemp || 1 > xTemp){ // print if wall column is INVALID
      if(debug)
      printf("  Invalid: column %d is outside range from 1 to %d\n",xTemp,setMaze->col);
    }
    else
    {               // if VALID with in maze dimension check start & end position
        if(xTemp-1 == setMaze->Sx && yTemp-1 == setMaze->Sy){
          if(debug) printf("  Invalid: attempting to block starting position\n");
        }
        else if(xTemp-1 == setMaze->Ex && yTemp-1 ==setMaze->Ey){
          if(debug) printf("  Invalid: attempting to block ending position\n");
        }
        else theMaze[yTemp-1][xTemp-1] = '*';          // create wall in maze
    }
}


bool checkEnd(int Ey, int Ex, maze* setMaze, bool debug){

    if(setMaze->col < Ex  || 1 > Ex){        // print if END row  is INVALID
      if(debug) printf("  Invalid: column %d is outside range from 1 to %d\n",Ex,setMaze->col);
    }
    else if(setMaze->row < Ey || 1 > Ey){    // print if END column  is INVALID
      if(debug) printf("  Invalid: row %d is outside range from 1 to %d\n",Ey,setMaze->row);
    }
    else
    {
      if(Ex != setMaze->Sx && Ey !=setMaze->Sy){    // if VALID END display it
          setMaze->Ex = Ex-1;
          setMaze->Ey = Ey-1;
          printf("  Ending position is at position %d,%d\n", Ey, Ex);
          return true;
      }
      else{ if(debug) printf("  Invalid: attempting to block starting position\n"); }
    }
    return false;
}


bool checkStart(int Sy, int Sx, maze* setMaze, bool debug){

    if(setMaze->row < Sy  || 1 > Sy){          // print if start row  is INVALID
      if(debug) printf("  Invalid: row %d is outside range from 1 to %d\n",Sy,setMaze->row);
    }
    else if(setMaze->col < Sx || 1 > Sx){   // print if start column  is INVALID
      if(debug) printf("  Invalid: column %d is outside range from 1 to %d\n",Sx,setMaze->col);
    }
    else
    {
      setMaze->Sx = Sx-1;                   // if VALID start prompt to screen
      setMaze->Sy = Sy-1;
      printf("  Starting position is at position %d,%d\n", Sy, Sx);
      return true;
    }
    return false;
}


bool checkSize(int row, int col, maze* setMaze, bool debug){

    if(row >= 1 && col >= 1)                // check of maze dimension is valid
    {
      setMaze->row = row;
      setMaze->col = col;
      printf("  Maze becomes size %d x %d\n", row, col);
      return true;
    }                                   // IN DEBUG MODE display is INVALID size
    else{ if(debug) printf("  Invalid: Maze sizes must be greater than 0\n"); }

    return false;
}


void initMaze(char *theMaze[], maze setMaze){
    int i, j;

    for (i = 0; i <  setMaze.row; i++)             // set position as unvisited
      for (j = 0; j < setMaze.col; j++)
        theMaze[i][j] = '.';

    theMaze[setMaze.Sy][setMaze.Sx] = 'S';         // set start & end position
    theMaze[setMaze.Ey][setMaze.Ex] = 'E';
}


void reversePrint_Delete(List **trail, int *jumpCounter){

    if(*trail == NULL) return;                    //trail does not exist return
    List * front  = *trail;
    List * back   = NULL;

    while(front ->prev != NULL)                       // move till last position
    {
        back = front;
        front = front->prev;
    }
    ++*jumpCounter;                                  // used for neater display
    printf("[%2d,%2d] ", front->yPos+1, front->xPos+1);   // print position y,x
    if(*jumpCounter == 6){printf("\n "); *jumpCounter = 0;}
    if(back == NULL) return;                   // everything was freed, return
    back->prev = NULL; free(front);            // cut off & delete last position
    reversePrint_Delete(trail, jumpCounter);   // recursive call till all freed
}


void displayResult(bool result, List** trail){
   int jumpCounter = 0;
   if(result){                                 // if path exist display path
     printf(" ");
     reversePrint_Delete(trail, &jumpCounter); // print path taken while freeing
     printf("\n\n         ** SOLUTION HAS BEEN FOUND  **\n\n");
   }
   else printf("\n         ** NO SOLUTION TO THIS MAZE **\n\n");
}


void create_search_Maze(char *file, bool debug){

    maze setMaze;
    List* trail = NULL;
    int i,j, xTemp, yTemp;
    bool valid_size  = false;
    bool valid_start = false;
    bool valid_end   = false;

    FILE * input = fopen(file, "r");                         // open file read

     while(fscanf (input, "%d %d", &yTemp, &xTemp) != EOF)   // read till EOF
     {
          if(!valid_size)                                    // check valid SIZE
                valid_size  = checkSize (yTemp, xTemp, &setMaze, debug);

          else if( !valid_start)                            // check valid START
                valid_start = checkStart(yTemp, xTemp, &setMaze, debug);

          else if( !valid_end)
          {                                                 // check valid END
                valid_end   = checkEnd  (yTemp, xTemp, &setMaze, debug);
                if(valid_end) break;   // valid size & start & end  break loop
          }
     }

     // if a file matches given file name BUT fails -- to be valid maze  ----
     if( !(valid_size && valid_start && valid_end) ){ errorPrompt(1);  return; }

     char ** theMaze = (char **)malloc( sizeof(char*) * setMaze.row);                               // create maze allocate space
     for(i = 0; i < setMaze.row; ++i )
     theMaze[i] = (char *)malloc((setMaze.col) * sizeof(char));
     initMaze(theMaze, setMaze);            // set start & end positions in MAZE

     while(fscanf (input, "%d %d", &yTemp, &xTemp) != EOF) // read wall position
        checkWall(yTemp, xTemp, &setMaze, theMaze, debug); // place wall in MAZE
     displayMaze(theMaze, setMaze, debug,0);     // show maze that is untraveled

     // search through the maze check if there is a solution
     bool searchReport = sendScout(theMaze, setMaze, &trail, debug);
     displayMaze(theMaze, setMaze, debug,1);       // show path Scout traveled
     displayResult(searchReport, &trail);          // prompt if solution exists

     // free 2D  allocated memory used for the maze;
     for(i = 0; i <  setMaze.row; ++i) free(theMaze[i]); free(theMaze);
     fclose(input);                                // close the particular file
}


void displayHeader(int fileCount, bool debug){
    // out put to screen header & if debug is on
    printf("\n\n"                                                        );
    printf("  *********************************************\n"           );
    if(debug) printf("  *                DEBUG MODE                 *\n" );
    printf("  *              #%d MAZE REPORT               *\n",fileCount);
    printf("  *********************************************\n\n"         );
}


void mazeExtract(int argc, char** argv, bool status){

      // list of accepted files
      const char accepted_files[][20] = {"mazeData1.txt", "mazeData2.txt",
                                         "mazeData3.txt", "mazeData4.txt"};
      bool fileFound = false;
      int fileCount = 0;
      int i,j;

      for (j = 0; j < argc; ++j){      // check cmd argument for matching file
          for (i = 0; i < 4; ++i){
              if(strcmp(argv[j], accepted_files[i]) == 0){
                  ++fileCount;   fileFound = true;
                  displayHeader(fileCount, status);    // TITLE  + Debug
                  create_search_Maze((char*)accepted_files[i], status); // actually search
              }
          }
      }
      if(!fileFound) errorPrompt(0);   // if NONE of cmd file match STD ERROR
}


int main(int argc, char **argv){
    bool status = isDebug(argc, argv);       // check for debug mode
    mazeExtract(argc, argv, status);         // extract file create check maze
    return 0;
}
