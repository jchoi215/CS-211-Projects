// 
//  Name:  Jae Rim Choi
//  NetID: jchoi215
//  Project: 5
//  connected to jchoi215Proj5.java
//

//==================================================================//
//                      INT LINK LIST & NODES                       //
//==================================================================//
 
class List
{
  private node head;


  public void List()                             
  { 
   head  = null;                      // as default, set head to null
  }


  public void show(){               
      node temp = head;              // display value in the link list
      while(temp != null)
      {
         System.out.print ("\n" + temp.getVal());
         temp = temp.getNext();
      }
  }
  

  public void push (int v1){
    node temp = new node (v1);            // push value to the stack
    temp.setNext(head);
    head = temp;
  }


  public void pop(){
     if(head == null) return;             // if head is empty return
     head = head.getNext();               // else pop head
     return;
  }


  public int isEmpty(){
    if(head != null) return 1;            // check of stack is empty
    else return 0;
  }


  public int top(){                     // get value on top of stack
    if(head == null) return -999;       
    return head.getVal();
  } 

  public int remaining(){   
    int count = 0;                      // count the number of nodes
    node temp = head;                   // in the link list
    
    while(temp!= null){
      count++;
      temp = temp.getNext();
    }
    return count;
  }

}


class node
{
    private int val;                    
    private node next;
    
    int getVal () {return val; }           // get value from node
    void setNext (node n) {next = n; }     // set next node
    node getNext() {return next; }         // retrieve next node

     node (int v1)                         
    {                                  // create node & insert value
      val = v1;
      next = null;
    }
}

